<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

if (!class_exists('vmPSPlugin')) {
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
}
if (!class_exists('VirtueMartModelCurrency')) {
	require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'currency.php');
}
if (!class_exists('AsphHelperSecure')) {
	require(JPATH_SITE . '/plugins/vmpayment/asph/asph/helpers/secure.php');
}
if (!class_exists('VirtueMartCart')) {
	require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
}
if (!class_exists('VirtueMartModelOrders')) {
	require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
}

class plgVmPaymentAsph extends vmPSPlugin {
	
	// Instance of class
    public static $_this = FALSE;

	public function __construct(& $subject, $config) {
		parent::__construct($subject, $config);
		$this->_loggable = TRUE;
		$this->tableFields = array_keys($this->getTableSQLFields());
		$this->_tablepkey = 'id';
		$this->_tableId = 'id';
		$varsToPush = $this->getVarsToPush();
		$varsToPush['payment_logos'] = array('', 'char');
		$varsToPush['cost_per_transaction'] = array('', 'float');
		$varsToPush['cost_percent_total'] = array('', 'char');
		$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
	}
	
	/**
	 * Create the table for this plugin if it does not yet exist.
	 *
	 */
	public function getVmPluginCreateTableSQL() {
		
		return $this->createTableSQL('Asph Table');
	}

	/**
	 * Fields to create the payment table
	 *
	 * @return string SQL Fileds
	 */
	public function getTableSQLFields() {
		$SQLfields = array(
			'id'											=> 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
			'virtuemart_order_id'					=> 'int(1) UNSIGNED',
			'order_number'							=> 'char(64)',
			'virtuemart_paymentmethod_id'	=> 'mediumint(1) UNSIGNED',
			'payment_name'						=> 'varchar(5000)',
			'payment_order_total'				=> 'decimal(15,5) NOT NULL DEFAULT \'0.00000\'',
			'payment_currency'					=> 'char(3)',
			'email_currency'						=> 'char(3)',
			'cost_per_transaction'				=> 'decimal(10,2)',
			'cost_percent_total'					=> 'decimal(10,2)',
			'tax_id'									=> 'smallint(1)'
		);

		return $SQLfields;
	}
	
	/**
	 * Create the table for this plugin if it does not yet exist.
	 * This functions checks if the called plugin is active one.
	 * When yes it is calling the standard method to create the tables
	 *
	 */
	public function plgVmOnStoreInstallPaymentPluginTable($jplugin_id) {
		
		return $this->onStoreInstallPluginTable ($jplugin_id);
	}
	
	/**
	 * plgVmDisplayListFEPayment
	 * This event is fired to display the pluginmethods in the cart (edit shipment/payment) for exampel
	 *
	 * @param object  $cart Cart object
	 * @param integer $selected ID of the method selected
	 * @return boolean True on succes, false on failures, null when this plugin was not selected.
	 * On errors, JError::raiseWarning (or JError::raiseError) must be used to set a message.
	 *
	 * @author Valerie Isaksen
	 * @author Max Milbers
	 */
	public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn) {
		
		return $this->displayListFE($cart, $selected, $htmlIn);
	}
	
	
	/**
     * We must reimplement this triggers for joomla 1.7
     */

    /**
     * plgVmOnCheckAutomaticSelectedPayment
     * Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
     * The plugin must check first if it is the correct type
     * @author Valerie Isaksen
     * @param VirtueMartCart cart: the cart object
     * @return null if no plugin was found, 0 if more then one plugin was found,  virtuemart_xxx_id if only one plugin is found
     *
     */
    public function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(),   &$paymentCounter) {
		
		return $this->onCheckAutomaticSelected($cart, $cart_prices);
    }

    /**
     * This method is fired when showing the order details in the frontend.
     * It displays the method-specific data.
     *
     * @param integer $order_id The order ID
     * @return mixed Null for methods that aren't active, text (HTML) otherwise
     * @author Valerie Isaksen
     */
    protected function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {
		
		$this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }

    /**
     * This method is fired when showing when priting an Order
     * It displays the the payment method-specific data.
     *
     * @param integer $_virtuemart_order_id The order ID
     * @param integer $method_id  method used for this order
     * @return mixed Null when for payment methods that were not selected, text (HTML) otherwise
     * @author Valerie Isaksen
     */
	public function plgVmOnShowOrderPrintPayment($order_number, $method_id) {
		
		return $this->onShowOrderPrint ($order_number, $method_id);
	}
	
	public function plgVmDeclarePluginParamsPayment($name, $id, &$data) {
		
		return $this->declarePluginParams ('payment', $name, $id, $data);
	}

	public function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {
		
		return $this->setOnTablePluginParams ($name, $id, $table);
	}
	  
	/**
	 * Display stored payment data for an order
	 *
	 */
	public function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id) {

		if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
			return NULL; // Another method was selected, do nothing
		}

		if (!($paymentTable = $this->getDataByOrderId($virtuemart_order_id))) {
			return NULL;
		}
		VmConfig::loadJLang('com_virtuemart');

		$html = '<table class="adminlist">' . "\n";
		$html .= $this->getHtmlHeaderBE ();
		$html .= $this->getHtmlRowBE ('COM_VIRTUEMART_PAYMENT_NAME', $paymentTable->payment_name);
		$html .= $this->getHtmlRowBE ('STANDARD_PAYMENT_TOTAL_CURRENCY', $paymentTable->payment_order_total . ' ' . $paymentTable->payment_currency);
		if ($paymentTable->email_currency) {
			$html .= $this->getHtmlRowBE ('STANDARD_EMAIL_CURRENCY', $paymentTable->email_currency );
		}
		$html .= '</table>' . "\n";
		return $html;
	}
     
	/**
	 * This event is fired after the payment method has been selected. It can be used to store
	 * additional payment info in the cart.
	 *
	 * @author Max Milbers
	 * @author Valérie isaksen
	 *
	 * @param VirtueMartCart $cart: the actual cart
	 * @return null if the payment was not selected, true if the data is valid, error message if the data is not vlaid
	 *
	 */
	public function plgVmOnSelectCheckPayment(VirtueMartCart $cart, &$msg) {
		
		return $this->OnSelectCheck($cart);
	}
	
	/**
	 * @param $virtuemart_paymentmethod_id
	 * @param $paymentCurrencyId
	 * @return bool|null
	 */
	public function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId) {

		if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
			return NULL; // Another method was selected, do nothing
		}

		if (!$this->selectedThisElement($method->payment_element)) {
			return FALSE;
		}

		$this->getPaymentCurrency($method);

		$paymentCurrencyId = $method->payment_currency;
		return;
	}
	
	/**
	 * Calculate the price (value, tax_id) of the selected method, It is called by the calculator
	 * This function does NOT to be reimplemented. If not reimplemented, then the default values from this function are taken.
	 */
	public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {
	
		return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
	}
	
	/**
	 * Check if the payment conditions are fulfilled for this payment method
	 *
	 * @author: Valerie Isaksen
	 *
	 * @param $cart_prices: cart prices
	 * @param $payment
	 * @return true: if the conditions are fulfilled, false otherwise
	 *
	 */
	protected function checkConditions($cart, $method, $cart_prices) {
		
		return TRUE;
	}

	/**
     * Prepare data and redirect to Systempay payment platform
	 * Reimplementation of vmPaymentPlugin::plgVmOnConfirmedOrder()
     */
	public function plgVmConfirmedOrder($cart, $order) {

		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return NULL; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($method->payment_element)) {
			return FALSE;
		}

		VmConfig::loadJLang('com_virtuemart_orders', TRUE);

		$this->getPaymentCurrency($method);
		$currency_code_3 = shopFunctions::getCurrencyByID($method->payment_currency, 'currency_code_3');
		$email_currency = $this->getEmailCurrency($method);

		//$totalInPaymentCurrency = self::getAmountInCurrency($order['details']['BT']->order_total,$method->payment_currency);
	
		// Prepare data that should be stored in the database
		$dbValues['payment_name'] = $this->renderPluginName($method);
		$dbValues['order_number'] = $order['details']['BT']->order_number;
		$dbValues['virtuemart_paymentmethod_id'] = $order['details']['BT']->virtuemart_paymentmethod_id;
		$dbValues['payment_currency'] = $currency_code_3;
		$dbValues['email_currency'] = $email_currency;
		//$dbValues['payment_order_total'] = $totalInPaymentCurrency['value'];
		$dbValues['payment_order_total'] = $order['details']['BT']->order_total;
		$dbValues['cost_per_transaction'] = $method->cost_per_transaction;
		$dbValues['cost_percent_total'] =  isset($method->cost_percent_total) ? $method->cost_percent_total : 0;
		$dbValues['tax_id'] = isset($method->tax_id) ? $method->tax_id : 0;
		$this->storePSPluginInternalData($dbValues);

		// Get db object
		$db = JFactory::getDBO();
		
		// Get country code
		$q = 'SELECT `country_2_code` FROM `#__virtuemart_countries` WHERE `virtuemart_country_id`="' .
				$order['details']['BT']->virtuemart_country_id . '" ';
		$db->setQuery($q);
		$country_2_code = $db->loadResult();
		
		// Get state name
		if($order['details']['BT']->virtuemart_state_id != 0) {
			$q = 'SELECT `state_2_code` FROM `#__virtuemart_states` WHERE `virtuemart_state_id`="' .
					$order['details']['BT']->virtuemart_state_id . '" ';
			$db->setQuery($q);
			$state_name = $db->loadResult();
		} else {
			$state_name = NULL;
		}

		// Preparation of data for sending
		$currency = CurrencyDisplay::getInstance('', $order['details']['BT']->virtuemart_vendor_id);
		$locale = isset($order['details']['BT']->order_language) 
					&& !empty($order['details']['BT']->order_language) 
					? str_replace('_', '-', $order['details']['BT']->order_language)
					: 'en-US';
		$paymentData = array(
			'transaction_uuid' 			=> uniqid($order['details']['BT']->order_number . '_'),
			'unsigned_field_names'		=> '',
			'signed_date_time' 			=> gmdate("Y-m-d\TH:i:s\Z",strtotime($order['details']['BT']->created_on)),
			'locale' 							=> $locale,
			'transaction_type' 			=> 'authorization',
			'reference_number' 			=> $order['details']['BT']->order_number,
			'amount' 						=> $order['details']['BT']->order_total,
			'currency' 						=> $currency->ensureUsingCurrencyCode($order['details']['BT']->order_currency),
			'order_id' 						=> $order['details']['BT']->order_number,
			'bill_to_email'		 			=> $order['details']['BT']->email,
			'bill_to_surname' 				=> $order['details']['BT']->last_name,
			'bill_to_forename' 			=> $order['details']['BT']->first_name,
			'bill_to_address_city'			=> $order['details']['BT']->city,
			'bill_to_address_line1'		=> $order['details']['BT']->address_1,
			'bill_to_address_country'	=> $country_2_code,
			'bill_to_address_state'		=> $state_name,
			'payment_method'			=> 'card',
			'merchant_defined_data5'	=> $order['details']['BT']->order_tax,
		);

		// Option selected credentials in the plugin configuration
		$credentials = array('profile_id', 'access_key', 'secret_key', 'url');
		$mode = empty($method->test_mode) ? 'live' : 'test';
		foreach($credentials as $credential) {
			$param = $mode . '_' . $credential;
			$paymentData[$credential] = $method->$param;
		}
		// Does not send the secret key
		$secretKey = $paymentData['secret_key'];
		unset($paymentData['secret_key']);

		$paymentData['test_mode'] = $method->test_mode;
		$paymentData['signed_field_names'] = implode(",", array_keys($paymentData));
		$paymentData['signature'] = AsphHelperSecure::sign($paymentData, $secretKey);

		// Called the template containing the confirmation button | tmpl
		$html = $this->renderByLayout('payment_confirmation', $paymentData);

		jRequest::setVar ('html', $html);
		return TRUE;
	}

	/**
	 * Check Systempay response, save order if not done by server call and redirect 
	 * to response page when client comes back from payment platform.
	 * index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&decision=ACCEPT&reasonCode=110&message=test
	 */
	public function plgVmOnPaymentResponseReceived() {
		
		$objRedirect = JFactory::getApplication();
		$responseData = JRequest::get('post');
		$url = "index.php?option=com_virtuemart&view=cart"; // url error page

		VmConfig::loadJLang('com_virtuemart_orders', TRUE);

		if (!is_array($responseData)) {
			// redirect to error page
			//$url .= '&error_response_received=1';
			$objRedirect->redirect(JRoute::_($url), JText::_('VMPAYMENT_ASPH_NOTIFICATION_DATA'));
			return FALSE;
		}

		if (count($responseData) < 1) {
			// redirect to error page
			//$url .= '&error_response_received=2';
			$objRedirect->redirect(JRoute::_($url), JText::_('VMPAYMENT_ASPH_NOTIFICATION_DATA'));
			return FALSE;
		}

		// Valid if the field is defined and is not empty
		$validateData = array(
			'req_reference_number' => JText::_('VMPAYMENT_ASPH_NOTIFICATION_NUMBER'),
			'decision' 					=> JText::_('VMPAYMENT_ASPH_NOTIFICATION_DECISION'),
			'reason_code' 				=> JText::_('VMPAYMENT_ASPH_NOTIFICATION_REASON_CODE'),
		);
		foreach($validateData as $key => $msg) {
			if( isset($responseData[$key]) ) {
				if ( ! empty($responseData[$key]) ) {
					continue;
				}
			}
			// redirect to error page
			//$url .= '&error_response_received=3';
			$objRedirect->redirect(JRoute::_($url), $msg);
			return FALSE;
		}

		// Get the id of the order, depending on the number of the order
		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($responseData['req_reference_number']);
		if (!$virtuemart_order_id){
			// redirect to error page
			$msg = JText::_(VMPAYMENT_ASPH_NOTIFICATION_REFERENCE_IS_NOT_FOUND) . $responseData['req_reference_number'];
			//$url .= '&error_response_received=4';
			$objRedirect->redirect(JRoute::_($url), $msg);
			return FALSE;
		}
		
		// Get the order data
		$order = VirtueMartModelOrders::getOrder($virtuemart_order_id);
		/*echo "<xmp>";
			print_r($order);
		echo "</xmp>";
		
		return false;*/
		
		// Gets the data from the xml configuration
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return NULL; // Another method was selected, do nothing
		}
		$mode = empty($method->test_mode) ? 'live' : 'test';
		$secretKey = $mode . '_secret_key';
		$statusDecision = isset($responseData['decision']) ? trim(strtoupper($responseData['decision'])) : $statusDecision;

		// Valid signature
		if($statusDecision !== 'CANCEL') {
			$signature = AsphHelperSecure::sign($responseData, $method->$secretKey);
			if (strcmp($responseData["signature"], $signature) !== 0) {
				 // redirect to error page
				//$url .= '&error_response_received=5';
				$objRedirect->redirect(JRoute::_($url), JText::_(VMPAYMENT_ASPH_NOTIFICATION_SIGNATURE));
			 }
		 }
		
		$message = isset($responseData['message']) ? $responseData['message'] : '';
		$reasonCode = isset($responseData['reason_code']) ? (int) trim($responseData['reason_code']) : 0;
		$statusCode = $this->_getNewPaymentStatus($statusDecision);
		if (!$statusCode) {
			// redirect to error page
			$msg = JText::_('VMPAYMENT_ASPH_NOTIFICATION_INVALID_RESPONSE_CODE') . $statusDecision;
			//$url .= '&error_response_received=6';
			$objRedirect->redirect(JRoute::_($url), $msg);
			return FALSE;
		}

		// Updates the status of the order if status diff
		if(trim(strtoupper($order['details']['BT']->order_status)) !== trim(strtoupper($statusCode))) {
			$order['order_status'] = $statusCode;
			$order['customer_notified'] = 1;
			$order['comments'] = $message . ", " . JText::_('VMPAYMENT_ASPH_NOTIFICATION_COMMENTS') . $reasonCode;
			$modelOrder = VmModel::getModel ('orders');
			$modelOrder->updateStatusForOneOrder($virtuemart_order_id, $order, TRUE);
		}
		// Response messages and redirection
		$clearCart = FALSE;

		switch ($statusDecision) {
			case 'ACCEPT':
				if($reasonCode === 100 || $reasonCode === 110) { // is approved
					$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_ACCEPT');
					$msgType = 'Message';
				} else {
					$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_ACCEPT_MISMATCH') . $reasonCode;
					$msgType = 'Warning';
				}
				$clearCart = TRUE;
				break;
			case 'CANCEL':
				$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_CANCEL');
				$msgType = 'Notice';
				break;
			case 'REVIEW':
				$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_REVIEW');
				$msgType = 'Warning';
				$clearCart = TRUE;
				break;
			case 'DECLINE':
				$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_DECLINE');
				$msgType = 'Notice';
				break;
			case 'ERROR':
				$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_ERROR');
				$msgType = 'Notice';
				break;
			default:
				$msg = JText::_('VMPAYMENT_ASPH_RESPONSE_ERROR');
				$msgType = 'Notice';
		}

		$msg .= ' - ' . $message . ' - ' . JText::_('VMPAYMENT_ASPH_RESPONSE_CODE') . $reasonCode;

		// We delete the old stuff
		if ($clearCart) {
			$cart = VirtueMartCart::getCart();
			$cart->emptyCart();
		}

		// redirect page completed
		$url = 'index.php?option=com_virtuemart&view=orders'; // url completed page
		$objRedirect->redirect(JRoute::_($url), $msg, $msgType);

		return TRUE;
	}

	/**
	 * Order status changed
	 * "P" Pending
	 * "U" Confirmed by shopper
	 * "C" Confirmed
	 * "X" Cancelled
	 * "R" Refunded
	 * "S" Shipped
	 * @param $currentStatus
	 * @return string
	 */
	private function _getNewPaymentStatus($currentStatus) {

		$statusList = array(
			"REVIEW"  => "P", 
			"DECLINE" => "D",
			"ACCEPT"  => "C",
			"CANCEL"  => "X",
			"ERROR"    => "E"
		);
		return $statusList[$currentStatus];
	}

}
// No close PHP tag