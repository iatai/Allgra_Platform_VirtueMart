<?php
// No direct access
defined('_JEXEC') or die('Restricted access');

class AsphHelperSecure {

	public function sign($params = array(), $secretKey = '') {
		return self::_signData(self::_buildDataToSign($params), $secretKey);
	}

	private function _signData($data, $secretKey) {
		return base64_encode(hash_hmac('sha256', $data, $secretKey, true));
	}

	private function _buildDataToSign($params) {
		$signedFieldNames = explode(",", $params["signed_field_names"]);
		foreach ($signedFieldNames as &$field) {
			$dataToSign[] = $field . "=" . $params[$field];
		}
		return self::_commaSeparate($dataToSign);
	}

	private function _commaSeparate($dataToSign) {
		return implode(",",$dataToSign);
	}

}

/*
echo AsphHelperSecure::sign(array("signed_field_names" => 'access_key', 'access_key' => 'cba48ce64b093b5fa8c65181eb5dcc7c'), '158cfa6242624708be074f0f37ea93f893e26b21812c4cd89d744aed2afdededa74df7d884874d9985b849d80632284047fcd1b018964110973c72d43d07a19e09e9a3a0551b405c8f2a62d0dd6661f73cec524016ee4b958855e3fb0bac6c73989b0b78f794449891c2ad9f0bd90c12658d5359e9e44c769c2d1a763686f1ee');
*/