<p><?php echo JText::_('VMPAYMENT_ASPH_TEMPLATE_TITLE'); ?></p>

<?php //if(!empty($viewData['test_mode'])) : ?>
<?php if(false) : ?>
<!-- Modo prueba activado -->
<table class="vmorder-done">
	<?php foreach($viewData as $name => $value) : ?>
	<tr>
		<td class="vmorder-done-payinfo"><?php echo $name; ?></td> 
		<td><?php echo $value; ?></td>
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>

<form action="<?php echo $viewData['url']; ?>" method="post"/>
	<?php foreach($viewData as $name => $value) : ?>
		<input type="hidden" name="<?php echo $name; ?>" value="<?php echo $value; ?>">
	<?php endforeach; ?>
        <button type="submit" name="confirm" id="checkoutFormSubmit" class="vm-button-correct">
            <span><?php echo JText::_('VMPAYMENT_ASPH_TEMPLATE_SUBMIT'); ?></span>
        </button>
	<!--input type="submit" id="asph-submit" value="<?php //echo JText::_( 'VMPAYMENT_ASPH_TEMPLATE_SUBMIT' ); ?>"/-->
</form>